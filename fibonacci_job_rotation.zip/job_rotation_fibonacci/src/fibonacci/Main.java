package fibonacci;
import javax.swing.JOptionPane;

public class Main {
	public static void main(String[] args) {
		//criando variaveis usads
		int atual = 0;
		int seguinte = 1;
		int result = -1;
		int esperado = Integer.parseInt(JOptionPane.showInputDialog("escolha o numero a ser verificado em Fibonacci!!"));
		//verificando se nao foram entrados os valores de atual e seguinte
		if(esperado == 0 || esperado == 1) {
				System.out.println("O numero encontrasse na sequencia !");
			}
		else {
			while (result != esperado) {
				//variaveis usadas no loop
				result = seguinte+atual;
				atual = seguinte;
				seguinte = result;
			
				//verificando e alertando se a sequencia ja passou do valor esperado
				if (result > esperado) {
					System.out.println("O numero nao se encontra na sequencia !");
					break;
				}
			
				//verificando e alertando que o valor foi encontrado
				else if(result == esperado) {
					System.out.println("O numero encontrasse na sequencia !");
				}
			}
		}//aviso de fim de aplicacao
		System.out.println("Fim da Aplicacao!");
	}
}
